#ifndef _FUNC_H_
#define _FUNC_H_

void show_info_a_variable (char* en_var);
void infoUsable();
void cleanEnv();
void deleteEnv(char* en_var);
void putEnv(char* en_var,char* value);
void setValue(char* en_var);

#endif